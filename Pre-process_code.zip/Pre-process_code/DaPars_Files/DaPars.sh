#!/bin/sh

## Run job in current directory, join stderr & stdout, 
## output file 'DaPars.sh'
#$ -cwd -j y -o DaPars.out

## reserve 14 slots per task on mem.q
#$ -pe slots 14 -q mem.q
DIR=/mnt/lustre/users/svenkat/Research/DaPars/DaPars1
CONF=/mnt/lustre/users/svenkat/Research/APA/BAMFiles/DaParsScripts
module load R/3.3.3
module load python/2.7.13
python ${DIR}/dapars-master/src/DaPars_main.py ${CONF}/DaPars_configureGENCODE146.txt