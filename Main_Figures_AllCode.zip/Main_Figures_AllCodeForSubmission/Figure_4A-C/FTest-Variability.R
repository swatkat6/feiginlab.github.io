## 8/2/2018 KHE
## notes for Swati V's project.

setwd("/mnt/lustre/users/svenkat/Research/Final_Figures/Figure 4A-C")
NM<-read.csv("2019-05-16-PDUI-NormalFilteredDaParsOutput.csv",row.names=1)[,-1]
dim(NM)
TM<-read.csv("2019-05-16-PDUI-TumorFilteredDaParsOutput.csv",row.names=1)[,-1]
dim(TM)
identical(rownames(NM),rownames(TM))

ff<-function(i)
{
  x<-as.numeric(NM[i,])
  y<-as.numeric(TM[i,])
  stat0<-c(mean(x,na.rm=TRUE), var(x,na.rm=TRUE),var(y,na.rm=TRUE), var.test(x,y,ratio=1,na.rm=TRUE)[3])
  stat0
}
XX<-t(sapply(1:nrow(NM),ff))
rownames(XX)<-rownames(NM)
colnames(XX)<-c("Mean\n(Norm)","Var\n(Norm)","Var\n(Tumor)", "FTest_Pvalue")
#pairs(XX)
write.csv(XX, file="VariabilitywithPval.csv")

##Denotes the p-values from the FTest of variance, are the tumor and normal means