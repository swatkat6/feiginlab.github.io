## 8/2/2018 KHE
## notes for Swati V's project.

setwd("/mnt/lustre/users/svenkat/Research/Final_Figures/Figure 4A-C")
NM<-read.csv("2019-05-16-PDUI-NormalFilteredDaParsOutput.csv",row.names=1)[,-1]
dim(NM)
TM<-read.csv("2019-05-16-PDUI-TumorFilteredDaParsOutput.csv",row.names=1)[,-1]
dim(TM)
identical(rownames(NM),rownames(TM))

###############################################################
############What are the changes in PDUI variance?#######################
ff<-function(i)
{
  x<-as.numeric(NM[i,])
  y<-as.numeric(TM[i,])
  stat0<-c(mean(x,na.rm=TRUE), var(x,na.rm=TRUE),var(y,na.rm=TRUE))
  stat0
}
XX<-t(sapply(1:nrow(NM),ff))
rownames(XX)<-rownames(NM)
colnames(XX)<-c("Mean\n(Norm)","Var\n(Norm)","Var\n(Tumor)")
##################################################################

####Plot the difference in variance######################################
#cc<-c("#00000011","#00000019","#0000FF55","#00FF0055")[1+2*(abs(XX[,2]-XX[,3])>.015)+(XX[,2]>XX[,3])]
cc<-c("#00000011","#00000019","#D2691E85","#4B008285")[1+2*(abs(XX[,2]-XX[,3])>.015)+(XX[,2]>XX[,3])]
plot(XX[,2]-XX[,3],cex=1.5,pch=21,col=cc,ylab=" ",xlab="", cex.axis=1.5, cex.lab=1.3,bg=cc)
abline(h=0.015*c(-1,1),lty=2,lwd=2,col="#00000085")
legend("topleft", c("High variance in normal","High variance in tumor"), pt.bg=c("#4B008285","#D2691E85"), pch=c(21,21),cex=0.98)
title(ylab="Var(Normal)-Var(Tumor)", line=2.5, cex.lab=1.3)
title(xlab="Genes", line=2.3, cex.lab=1.3)
##########################################################################


