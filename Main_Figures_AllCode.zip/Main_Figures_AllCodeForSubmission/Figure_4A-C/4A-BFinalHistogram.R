setwd("/mnt/lustre/users/svenkat/Research/Final_Figures/Figure 4A-C")
PDUI.N<-read.csv("/mnt/lustre/users/svenkat/Research/Final_Figures/Figure 4A-C/2019-05-16-PDUI-NormalFilteredDaParsOutput.csv",row.names=1, stringsAsFactors = FALSE)[,-1]
PDUI.T<-read.csv("/mnt/lustre/users/svenkat/Research/Final_Figures/Figure 4A-C/2019-05-16-PDUI-TumorFilteredDaParsOutput.csv",row.names=1,stringsAsFactors = FALSE)[,-1]


#ALDOA ENST00000412304.5
d1<-density(as.numeric(PDUI.N[c("ENST00000412304"),]),from=0,to=1)
d2<-density(as.numeric(PDUI.T[c("ENST00000412304"),]),from=0,to=1)
plot(d1,xlim=c(0,1),type="n", main="", xlab="",ylab="",cex.axis=1.5)
title("ALDOA", line = 0.5) #adjust title position
title(xlab="PDUI",ylab="Frequency density", line = 2.4,cex.lab=1.4)
polygon(c(d1$x,1),c(d1$y,0),xlim=c(0,1),col="#4B008285") #col="#00FF0055"
polygon(c(0,d2$x),c(0,d2$y),xlim=c(0,1),col="#D2691E85")
legend("topleft", c("Normal", "Tumor"), fill=c("#4B008285","#D2691E85"), cex=1.2)

#discrete histogram
#hist(PDUI.N[277,],xlim=c(0,1),breaks=20,col="#00FF0055",freq=FALSE,main="ALDOA")
#hist(PDUI.T[277,],xlim=c(0,1),breaks=20,add=TRUE,col="#0000FF55",freq=FALSE)


#FLNA ENST00000422373.4
d1<-density(as.numeric(PDUI.N[c("ENST00000422373"),]),from=0,to=1)
d2<-density(as.numeric(PDUI.T[c("ENST00000422373"),]),from=0,to=1)
plot(d1,xlim=c(0,1),type="n", main="", xlab="",ylab="",cex.axis=1.5)
title("FLNA", line = 0.5) #adjust title position
title(xlab="PDUI",ylab="Frequency density", line = 2.4,cex.lab=1.4)
polygon(c(d1$x,1),c(d1$y,0),xlim=c(0,1),col="#4B008285") #col="#00FF0055"
polygon(c(0,d2$x),c(0,d2$y),xlim=c(0,1),col="#D2691E85")
legend("topleft", c("Normal", "Tumor"), fill=c("#4B008285","#D2691E85"), cex=1.2)

#https://www.rapidtables.com/web/color/Gold_Color.html
#https://www.rapidtables.com/web/color/purple-color.html

# TRIP10, ENO1, PAF1, CSNK1A1 have similar profile to ALDOA. 